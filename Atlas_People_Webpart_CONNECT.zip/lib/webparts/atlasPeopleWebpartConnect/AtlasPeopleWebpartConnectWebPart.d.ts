import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IAtlasPeopleWebpartConnectWebPartProps } from './IAtlasPeopleWebpartConnectWebPartProps';
export default class AtlasPeopleWebpartConnectWebPart extends BaseClientSideWebPart<IAtlasPeopleWebpartConnectWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    private validateBtnText;
    private onTextChange;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AtlasPeopleWebpartConnectWebPart.d.ts.map