declare const styles: {
    a_c_50a7110f: string;
    b_c_50a7110f: string;
    l_c_50a7110f: string;
    atlasPeopleWebpartConnect: string;
    container: string;
    box: string;
    'box-row': string;
    'box-cell': string;
    box1: string;
    box2: string;
    box3: string;
    wrapper: string;
    myColl: string;
    myRow: string;
    card2: string;
    card: string;
    image: string;
    aboutpeople: string;
    peoplePhoto: string;
    subTitle: string;
    description: string;
    readMore: string;
    modalHeader: string;
    reqVisitBtn: string;
    personMove: string;
};
export default styles;
//# sourceMappingURL=AtlasPeopleWebpartConnect.module.scss.d.ts.map