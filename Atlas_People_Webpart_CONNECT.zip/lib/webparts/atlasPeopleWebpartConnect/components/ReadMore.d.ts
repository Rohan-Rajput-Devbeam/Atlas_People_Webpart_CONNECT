import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
export declare class ReadMore extends React.Component<any, any> {
    constructor(props: any);
    toggleReadMore: () => void;
    sliceStringWithWords: (inputString: any, limit: any) => any;
    render(): JSX.Element;
}
//# sourceMappingURL=ReadMore.d.ts.map