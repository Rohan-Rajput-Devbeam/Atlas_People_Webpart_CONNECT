import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
export declare class DescriptionModal extends React.Component<any, any> {
    closeModal: (e: any) => void;
    constructor(props: any);
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=DescriptionModal.d.ts.map