import * as React from 'react';
import { IAtlasPeopleWebpartConnectProps } from './IAtlasPeopleWebpartConnectProps';
import 'bootstrap/dist/css/bootstrap.css';
export interface IAtlasPeopleWebpartConnectState {
    showDescriptionModal: boolean;
    currentDataset: any;
}
export default class AtlasPeopleWebpartConnect extends React.Component<IAtlasPeopleWebpartConnectProps, IAtlasPeopleWebpartConnectState> {
    constructor(props: IAtlasPeopleWebpartConnectProps);
    openModal(id: number): Promise<void>;
    closeModal(): void;
    sliceStringWithWords: (inputString: any, limit: any) => any;
    render(): React.ReactElement<IAtlasPeopleWebpartConnectProps>;
}
//# sourceMappingURL=AtlasPeopleWebpartConnect.d.ts.map