/* tslint:disable */
require("./AtlasPeopleWebpartConnect.module.css");
const styles = {
  a_c_50a7110f: 'a_c_50a7110f_fdc5e78f',
  b_c_50a7110f: 'b_c_50a7110f_fdc5e78f',
  l_c_50a7110f: 'l_c_50a7110f_fdc5e78f',
  atlasPeopleWebpartConnect: 'atlasPeopleWebpartConnect_fdc5e78f',
  container: 'container_fdc5e78f',
  box: 'box_fdc5e78f',
  'box-row': 'box-row_fdc5e78f',
  'box-cell': 'box-cell_fdc5e78f',
  box1: 'box1_fdc5e78f',
  box2: 'box2_fdc5e78f',
  box3: 'box3_fdc5e78f',
  wrapper: 'wrapper_fdc5e78f',
  myColl: 'myColl_fdc5e78f',
  myRow: 'myRow_fdc5e78f',
  card2: 'card2_fdc5e78f',
  card: 'card_fdc5e78f',
  image: 'image_fdc5e78f',
  aboutpeople: 'aboutpeople_fdc5e78f',
  peoplePhoto: 'peoplePhoto_fdc5e78f',
  subTitle: 'subTitle_fdc5e78f',
  description: 'description_fdc5e78f',
  readMore: 'readMore_fdc5e78f',
  modalHeader: 'modalHeader_fdc5e78f',
  reqVisitBtn: 'reqVisitBtn_fdc5e78f',
  personMove: 'personMove_fdc5e78f'
};

export default styles;
/* tslint:enable */