export interface IAtlasPeopleWebpartConnectWebPartProps {
  description1: any;
  description2: any;
  description3: any;
  description4: any;
  description5: any;

  filePickerResult1: any;
  filePickerResult2: any;
  filePickerResult3: any;
  filePickerResult4: any;
  filePickerResult5: any;

  role1: any;
  role2: any;
  role3: any;
  role4: any;
  role5: any;


  profileName1: any;
  profileName2: any;
  profileName3: any;
  profileName4: any;
  profileName5: any;

  htmlCode1: any;

  selectBrand1: any;
  selectBrand2: any;
  selectBrand3: any;
  selectBrand4: any;
  selectBrand5: any;

  byline1: any;
  byline2: any;
  byline3: any;
  byline4: any;
  byline5: any;

  collectionData1: any[];
  collectionData2: any[];
  collectionData3: any[];
  collectionData4: any[];
  collectionData5: any[];

  fb1: any;
  fb2: any;
  fb3: any;
  fb4: any;
  fb5: any;

  insta1: any;
  insta2: any;
  insta3: any;
  insta4: any;
  insta5: any;

  twitter1: any;
  twitter2: any;
  twitter3: any;
  twitter4: any;
  twitter5: any;

  yt1: any;
  yt2: any;
  yt3: any;
  yt4: any;
  yt5: any;

  linkedIn1: any;
  linkedIn2: any;
  linkedIn3: any;
  linkedIn4: any;
  linkedIn5: any;

  yammer1: any;
  yammer2: any;
  yammer3: any;
  yammer4: any;
  yammer5: any;

  buttonHyperlink1: any;
  buttonHyperlink2: any;
  buttonHyperlink3: any;
  buttonHyperlink4: any;
  buttonHyperlink5: any;

  buttonText1: any;
  buttonText2: any;
  buttonText3: any;
  buttonText4: any;
  buttonText5: any;

  buttonCollectionData1 : any;
  buttonCollectionData2: any;
  buttonCollectionData3 : any;
  buttonCollectionData4 : any;
  buttonCollectionData5 : any;

}
