declare interface IAtlasPeopleWebpartConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AtlasPeopleWebpartConnectWebPartStrings' {
  const strings: IAtlasPeopleWebpartConnectWebPartStrings;
  export = strings;
}
